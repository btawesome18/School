function out = M3(c)
%DCM 
     out = [cos(c),sin(c),0;-sin(c),cos(c),0;0,0,1];
     
end