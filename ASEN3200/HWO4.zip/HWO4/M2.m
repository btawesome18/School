function out = M2(b)

     out = [cos(b),0,-sin(b);0,1,0;sin(b),0,cos(b)];

end