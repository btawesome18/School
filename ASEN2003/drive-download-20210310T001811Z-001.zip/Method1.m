function [W] = Method1(M,M0,B,angle,r,I,g)
%UNTITLED3 Summary of this function goes here
%   Detailed explanation goes here
    
    Num = 2*(M+M0)*(sind(B)*angle)*r*g;
    Dom = (((M+M0)*(r^2))+I);
    
    W = sqrt(Num/Dom);
    
    
end

