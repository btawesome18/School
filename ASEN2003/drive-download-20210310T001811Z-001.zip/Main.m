load("balanced_1")
load("balanced_2")

angle1 = balanced_1(:,2);
angle2 = balanced_2(:,2);

omega1 = balanced_1(:,2);

M = 11.7;
M0 = 0.7;
I = M*(0.203^2);
r = 0.235;
B = 5.5;
g = 9.81;
h0 = 0;

wThe1 = Method1(M,M0,B,(angle1),r,I,g);

hold on
plot(angle1,wThe1);
plot(angle1,balanced_1(:,3),'*');

maxt = 0;
maxd = 10000;

w2The1 = Method2(M,M0,B,angle1,r,I,g,-0.75); %-0.75 found

plot(angle1,w2The1);
